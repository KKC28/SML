#Komal Kumari(MT19124)
from __future__ import division
import numpy as np
import math
import matplotlib.pyplot as plt
from scipy.spatial import distance

#Discriminant Function
def dicsriminantFunction(x,mean,prior,sigma,dimension):
    #print(mean)
    temp = math.pow(distance.euclidean(x, mean),2)
    temp_=math.pow(2*math.pi,1/dimension)*sigma
    #print(d)
    return math.log(1/temp_,2)-(temp/(2*sigma*sigma))+math.log(prior,2)
prior=1/3
mean=[[0.5],[0.5]]
x=[[1],[1]]
sigma=1
dimension=2
result=dicsriminantFunction(np.transpose(x),np.transpose(mean),prior,sigma,dimension)
print(result)

