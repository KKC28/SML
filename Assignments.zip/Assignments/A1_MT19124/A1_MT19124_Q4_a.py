#Komal Kumari(MT19124)
import numpy as np
import math
import matplotlib.pyplot as plt
from scipy.spatial import distance

# for d-D variable X
def mulitvariateNormalDistribution(mean,covariance,sample_size):
    x=np.random.multivariate_normal(mean,covariance,sample_size)
    print("Shape",x.shape)
    print("Samples:",x)
    
mean=[1,2,3,4]
covariance=[[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]]
sample_size=5
mulitvariateNormalDistribution(mean,covariance,sample_size)