#!/usr/bin/env python
# coding: utf-8

# # Question 1

# In[1200]:


#from __future__ import division
import numpy as np
import random
from sklearn.metrics import mean_squared_error
np.set_printoptions(precision=None, suppress=True)


# In[1201]:


#reading the file
with open("Dataset.data") as fin:
    data = np.empty((14), float)
    #print(data.shape)
    for line in fin:
        line = line.rstrip('\n')
        while line.endswith('\\'):
            line = line[:-1] + next(fin).rstrip('\n')
        temp=np.fromstring(line,dtype="float",sep=' ')
        data=np.row_stack((data,temp))
    #print(data.shape)


# In[1202]:


data=data[1:]
print("Actual data:",data.shape)
print(data[0:5,:])


# # Q_A

# In[1203]:


def trainTestSplit(data,split):
    train=list()
    train_length=len(data)*split
    test=list(data)
    while(len(train)<train_length):
        index=random.randrange(len(test))
        train.append(test.pop(index))
    return np.asarray(test),np.asarray(train)


# In[1204]:


test,train=trainTestSplit(data,0.80)
print("Test:",test.shape)
print("Train:",train.shape)
#print("Test:",train)


# # Q_B

# In[1205]:


#appending 1 to the end
def modifyIndependentDataset(train):
    #print("train shape:",train.shape)
    independent=train[:,:-1]
    dependent=train[:,-1]
    ones=np.ones([len(independent),1])
    #print(ones.shape)
    independent=independent.T
    ones=ones.T
    #print(ones.shape)
    #print(independent.shape)
    independent=np.concatenate((independent,ones),axis=0)
    return independent,dependent


# In[1206]:


def wCalculation(independent,dependent):
    # calculating w
    #print(np.dot(np.linalg.inv((np.dot(independent,independent.T))),independent))
    w=np.dot(np.dot(np.linalg.inv((np.dot(independent,independent.T))),independent),dependent)
    return w


# In[1207]:


def predict(w,data):
    predicted_value=np.dot(w.T,data)
    return predicted_value


# In[1208]:


def rmseCalculation(predicted_value,dependent):
    #calculating RMSE
    rmse=np.sqrt(np.sum(np.square(np.subtract(dependent,predicted_value)))/len(predicted_value))
    #print(np.subtract(dependent,predicted_value))
    #rmse=np.sqrt(mean_squared_error(dependent,predicted_value))
    #rmse=np.sqrt(np.sum(np.square(np.subtract(dependent,predicted_value)))/len(predicted_value))
    #print('{0:.10f}'.format(rmse))
    return rmse


# In[1209]:


# independent=train[:,:-1]
# #print(independent.shape)
# dependent=train[:,-1]
# print("Dependent shape:",dependent.shape)
independent,dependent=modifyIndependentDataset(train)
print("Independent shape:",independent.shape)
print("Dependent shape:",dependent.shape)
w=wCalculation(independent,dependent)
print("W shape:",w.shape)
#print(w)
predicted_value=predict(w,independent)
print("prediceted shape:",predicted_value.shape)
rmse_train=rmseCalculation(predicted_value,dependent)
print("RMSE_train:",rmse_train)

independent_test,dependent_test=modifyIndependentDataset(test)
predicted_value=predict(w,independent_test)
rmse_test=rmseCalculation(predicted_value,dependent_test)
print("RMSE_test:",rmse_test)


# # Q_C

# In[1210]:


def intilizedata(train):
    train_new=train[:,-2:]
    #print("New training data shape:",train_new.shape)
    return train_new


# # Q_D

# In[1211]:


#Cross validation by k folds
def kFoldCrossValidation(train_new,no_of_folds):
    fold_length=int(len(train_new)/no_of_folds)
    #temp=train_new
    #print(len(train_new))
    #print(fold_length)
    fold_list=list()
    for i in range(no_of_folds):
        #train_new=temp
        fold=np.ones([1,len(train_new[0])])
        #print(fold.shape)
        while(len(fold)<=fold_length):
            index=random.randrange(len(train_new))
            #print(index)
            fold=np.row_stack((fold,train_new[index,:]))
            train_new=np.delete(train_new, obj=index, axis=0)
            #print("train_new:",train_new.shape)
        #print("fold shape:",fold.shape)
        fold_list.append(fold[1:,:])
    #print(fold_list[4].shape)
    return fold_list


# In[1212]:


train_new=intilizedata(train)
fold_list=kFoldCrossValidation(train_new,5)
print("folds shape:",fold_list[4].shape)


# # Q_E

# In[1233]:


def predictCrossValidation(fold_list):
    validation_error=0
    train_error=0
    for i in range(len(fold_list)):
        fold=np.ones([1,len(fold_list[0][0])])
        #print(fold.shape)
        for j in range(len(fold_list)):
            if i!=j:
                fold=np.row_stack((fold,fold_list[j]))
        fold=fold[1:,:]
        independent,dependent=modifyIndependentDataset(fold)
        w=wCalculation(independent,dependent)
        #print(w.shape)
        predicted_value=predict(w,independent)
        train_error=train_error+rmseCalculation(predicted_value,dependent) 
        independent,dependent=modifyIndependentDataset(fold_list[i])
        predicted_value=predict(w,independent)
        validation_error+=rmseCalculation(predicted_value,dependent)
    return validation_error/len(fold_list),train_error/len(fold_list)


# In[1234]:


def trainNewModification(train_new,deg):
    #print(len(train))
    final=np.ones([len(train_new),1])
    temp=train_new
    train_new=train_new[:,0:1]
    #print(train.shape)
    #print(train_new.shape)
    for i in range(deg,0,-1):
        #print(i)
        final=np.column_stack((final,np.power(train_new,i)))
    #print(final.shape)
    final=np.column_stack((final,temp[:,-1:]))
    return final[:,1:]


# In[1235]:


degree=[1,2,5,6,10,12,19,20]
#degree=[1,2,3,4,5,6,7,8,9,10,11,12,13,18,19,20]
validation_list=[]
train_list=[]
m=[]
for i in range(len(degree)):
    deg=degree[i]
    print("Degree:",deg)
    train_new=intilizedata(train)
    train_new=trainNewModification(train_new,deg)
    #print(train_new.shape)
    fold_list=kFoldCrossValidation(train_new,5)
    #print(fold_list[0].shape)
    validation_error,train_error=predictCrossValidation(fold_list)
    validation_list.append(validation_error)
    train_list.append(train_error)
    m.append(deg)
    print("training error:",train_error)
    print("validation_error:",validation_error)


# # Q_H

# In[1236]:


def plotting(validation_list,train_list,m):
    plt.plot(m, validation_list, 'r') 
    plt.plot(m, train_list, 'b')
    plt.show()


# In[1237]:


import matplotlib.pyplot as plt 
plotting(validation_list,train_list,m)


# # Q_G

# In[1239]:


#degree 12 is choosen
train_new=intilizedata(train)
train_new=trainNewModification(train_new,12)
#print(train_new.shape)
independent,dependent=modifyIndependentDataset(train_new)
w=wCalculation(independent,dependent)
#print(w.shape)
predicted_value=predict(w,independent)
train_error=rmseCalculation(predicted_value,dependent)
print("training error:",train_error)
test_new=intilizedata(test)
#print(test_new.shape)
test_new=trainNewModification(test_new,12)
independent,dependent=modifyIndependentDataset(test_new)
#print(test_new.shape)
predicted_value=predict(w,independent)
test_error=rmseCalculation(predicted_value,dependent)
print("test error:",test_error)


# # Question 2

# In[1240]:


from numpy import genfromtxt
data_new= genfromtxt('data.csv', delimiter=',')
data_new=data_new[1:,:]
print("data shape",data_new.shape)


# In[1241]:


#degree=[1,2,5,6,10,12,19,20]
degree=[1,2,4,5,10,11,12,15,16,17,19,20,21,22,23,25,26,28,29]
validation_list_new=[]
train_list_new=[]
m_new=[]
for i in range(len(degree)):
    deg=degree[i]
    print("Degree:",deg)
    train_new_temp=intilizedata(data_new)
    #print(train_new_temp.shape)
    train_new_temp=trainNewModification(train_new_temp,deg)
    #print(train_new.shape)
    fold_list_new=kFoldCrossValidation(train_new_temp,5)
    #print(fold_list[0].shape)
    validation_error_new,train_error_new=predictCrossValidation(fold_list_new)
    validation_list_new.append(validation_error_new)
    train_list_new.append(train_error_new)
    m_new.append(deg)
    print("training error:",train_error_new)
    print("validation_error:",validation_error_new)


# In[1081]:


import matplotlib.pyplot as plt 
plotting(validation_list_new,train_list_new,m_new)


# In[1242]:


def plottingData(x,y):
    plt.scatter(x, y, label= "stars", color= "green", marker= "*", s=30)
    plt.scatter(data_new[:,0:1], data_new[:,1:], label= "stars", color= "red", marker= "*", s=30) 
    plt.show()


# In[1245]:


degree=[1,2,4,5,10,15,30]
#degree=[15]
for i in range(len(degree)):
    deg=degree[i]
    print("Degree:",deg)
    train_new_temp=intilizedata(data_new)
    #print(train_new_temp.shape)
    train_new_temp=trainNewModification(train_new_temp,deg)
    #print(train_new_temp.shape)
    independent_new,dependent_new=modifyIndependentDataset(train_new_temp)
    print("Independent shape:",independent_new.shape)
    print("Dependent shape:",dependent_new.shape)
    w_new=wCalculation(independent_new,dependent_new)
    print("W shape:",w_new.shape)
    predicted_value_new=predict(w_new,independent_new)
    print("predcited shape",predicted_value_new.shape)
    rmse=rmseCalculation(predicted_value_new,dependent_new)
    print("RMSE:",rmse)
    plottingData(data_new[:,0:1],predicted_value_new)


# In[ ]:




