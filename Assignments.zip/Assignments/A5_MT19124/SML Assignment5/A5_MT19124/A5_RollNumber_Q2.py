# # Gaussian Processes Regression

# In[69]:


import numpy as np
import math
from matplotlib import pyplot as plt
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel as C  
from sklearn.linear_model import LinearRegression
import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error
from pprint import pprint
import random
import matplotlib.pyplot as plt
from random import randrange
import seaborn as sns



# In[70]:


dataset=pd.read_csv("GP.csv",header=[0])
dataset = dataset.drop("Sr.No", axis=1)
dataset = dataset.rename(columns={"Signal Strength(DBM)": "label"})
print("Data Shape:",dataset.shape)

test_dataframe=dataset.loc[dataset['Distance'].isin([1,3,5,7,9])]
train_dataframe=dataset.loc[dataset['Distance'].isin([0,2,4,6,8,10,11])]
X=np.array(train_dataframe['Distance'])
y=np.array(train_dataframe['label'])
X_test=np.array(test_dataframe['Distance'])
y_test=np.array(test_dataframe['label'])
X = np.atleast_2d(X).T
X_test = np.atleast_2d(X_test).T
print("Train points",X)
print("Value at Train points",y)


# In[71]:


print("Train points",X_test)


# In[256]:


temp=np.var(y)


# In[257]:


print(temp)


# In[411]:


#kernel = C(1, (1e-3, 1e3)) * RBF(1, (1e-2, 1e2))
#kernel=C(111.67, (111, 1111)) * RBF(1,(1,1))
gp = GaussianProcessRegressor(n_restarts_optimizer=6,normalize_y=True)
gp.fit(X, y)
print(gp)
print("GPML kernel: %s" % gp.kernel_)
print("Log-marginal-likelihood: %.3f"
      % gp.log_marginal_likelihood(gp.kernel_.theta))


# In[416]:


mean,sigma=gp.predict(X_test,return_std=True)
print("mean value at Test points",mean)
print("Variance at Test point predictions ",sigma)


# In[417]:


mse=mean_squared_error(y_test, mean)
print(mse)


# In[418]:


plt.figure()
plt.plot(X, y, 'r.', markersize=10, label='Observations')
plt.plot(X_test, mean, 'b*', label='Prediction')
plt.fill(np.concatenate([X_test, X_test[::-1]]),
         np.concatenate([mean-1.960*sigma,
                        (mean+1.960*sigma)[::-1]]),
         alpha=.5, fc='b', ec='None', label='95% confidence interval')
plt.xlabel('$x$')
plt.ylabel('$f(x)$')
plt.ylim(-65, -30)
plt.legend(loc='upper left')
plt.show()

# In[ ]:

