#!/usr/bin/env python
# coding: utf-8

# In[283]:


#Komal Kumari(MT19124)
#Rupali(MT19095)


# # Dataset

# Predict Bitcoin price for next 30 days

# In[269]:


#import libraries
import tensorflow as tf
from keras.models import Sequential
from keras.layers import Dense, SimpleRNN, Dropout,Flatten
import numpy as np
from statsmodels.tsa.stattools import adfuller
from pandas.plotting import autocorrelation_plot
import seaborn as sns
from sklearn.decomposition import PCA
from matplotlib import pyplot as plt
from sklearn.metrics import mean_squared_error
from math import sqrt
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel as C
from sklearn.linear_model import LinearRegression
import numpy as dragon
from sklearn.metrics import mean_squared_error
from binance.client import Client
import datetime
from sklearn.preprocessing import StandardScaler
import pandas as pd
from sklearn import preprocessing
import numpy as np
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')
from collections import deque
import random
import pandas as pd
from collections import deque
import random
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, LSTM,BatchNormalization
from tensorflow.keras.callbacks import TensorBoard
from tensorflow.keras.callbacks import ModelCheckpoint, ModelCheckpoint
import time
from sklearn import preprocessing


from sklearn.model_selection import KFold, StratifiedKFold
from sklearn.metrics import confusion_matrix, accuracy_score, classification_report
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestRegressor
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.externals import joblib
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import mean_squared_error


# using BINANCE Exchange API for getting the dataset

# In[270]:


api_key='kikMm5wCFBWPs8i6apOEPBopkfCMDFqhWaonzOrFjtUyZoVb0Zimj2KN5k3JN4L3'
api_secret='7oRcw5SiuSYSVUXWELkKZomLQ6UQFfAsuYWxOVbmnKTulxUxZMCUCtmQ0RwlWW42'
client = Client(api_key, api_secret)


# Fetching dataset for top three cryptocurrency: Bitcoin,Ripple and Ethereum

# In[271]:


#Bitcoin
symbol='BTCUSDT'
BTC=client.get_historical_klines(symbol=symbol,interval=Client.KLINE_INTERVAL_1MINUTE,start_str="48 hours ago UTC")
#Ripple
symbol='XRPUSDT'
RIP=client.get_historical_klines(symbol=symbol,interval=Client.KLINE_INTERVAL_1MINUTE,start_str="48 hours ago UTC")
#Ethereum
symbol='ETHUSDT'
ETH=client.get_historical_klines(symbol=symbol,interval=Client.KLINE_INTERVAL_1MINUTE,start_str="48 hours ago UTC")


# adding columns to the dataset

# In[272]:


BTC=pd.DataFrame(BTC,columns=['Open time','Open','High','Low','Close','Volume','Close time','Quote asset volume','Number of trades','Taker buy base asset volume','Taker buy quote asset volume','Can be ignored'])
RIP=pd.DataFrame(RIP,columns=['Open time','Open','High','Low','Close','Volume','Close time','Quote asset volume','Number of trades','Taker buy base asset volume','Taker buy quote asset volume','Can be ignored'])
ETH=pd.DataFrame(ETH,columns=['Open time','Open','High','Low','Close','Volume','Close time','Quote asset volume','Number of trades','Taker buy base asset volume','Taker buy quote asset volume','Can be ignored'])


# Shape of the dataset

# In[273]:


print("Shape of the dataset:",BTC.shape)
print("Shape of the dataset:",RIP.shape)
print("Shape of the dataset:",ETH.shape)


# Datatypes information

# In[274]:


print("BTC Datatypes:")
print(BTC.dtypes)


# Open time and close time was converted to date-time format from String 

# In[275]:


BTC['Open time']=pd.to_datetime(BTC['Open time'],unit='ms')
BTC['Close time']=pd.to_datetime(BTC['Close time'],unit='ms')
RIP['Open time']=pd.to_datetime(RIP['Open time'],unit='ms')
RIP['Close time']=pd.to_datetime(RIP['Close time'],unit='ms')
ETH['Open time']=pd.to_datetime(ETH['Open time'],unit='ms')
ETH['Close time']=pd.to_datetime(ETH['Close time'],unit='ms')


# Close price and volume traded are converted to float

# In[276]:


BTC['Close']=BTC['Close'].astype(float)
BTC['Volume']=BTC['Volume'].astype(float)
BTC['Open']=BTC['Open'].astype(float)
BTC['High']=BTC['High'].astype(float)
BTC['Low']=BTC['Low'].astype(float)
RIP['Close']=RIP['Close'].astype(float)
RIP['Volume']=RIP['Volume'].astype(float)
RIP['Open']=RIP['Open'].astype(float)
RIP['High']=RIP['High'].astype(float)
RIP['Low']=RIP['Low'].astype(float)
ETH['Close']=ETH['Close'].astype(float)
ETH['Volume']=ETH['Volume'].astype(float)
ETH['Open']=ETH['Open'].astype(float)
ETH['High']=ETH['High'].astype(float)
ETH['Low']=ETH['Low'].astype(float)


# Statistics of each cyptocurrency

# In[277]:


print("BTC statistics:")
print(BTC.describe())
print("RIP statistics:")
print(RIP.describe())
print("ETH statistics:")
print(ETH.describe())


# Checking for missing values

# In[278]:


print("BTC Missing Details:")
print(BTC.isnull().any())
print("RIP Missing Details:")
print(RIP.isnull().any())
print("ETH Missing Details:")
print(ETH.isnull().any())


# In[191]:


#BTC.set_index('Open time',inplace=True)


# Visualizations

# In[163]:


BTC['Close'].plot(figsize=(20,10),title='Close Price vs TimeStamp')
plt.xlabel('TimeStamp') 
plt.ylabel('Close Price') 


# In[164]:


from pandas import Series
from matplotlib import pyplot
from statsmodels.tsa.seasonal import seasonal_decompose

series=BTC['Close']

print("Additive Close=Trends+Seasonal+Residual")
result = seasonal_decompose(series, model='additive', period=1)
result.plot()
pyplot.show()

print("Multplicative Close= Trends*Seasonal*Residual")
result = seasonal_decompose(series, model='multiplicative', period=1)
result.plot()
pyplot.show()


# In[282]:


sns.heatmap(combined_df.corr(), annot=True, cmap='RdYlGn', linewidths=0.1, vmin=0)


# In[268]:


autocorrelation_plot(series)


# preprocessing

# In[279]:


combined_df = pd.DataFrame()
currencies = ["BTC","RIP","ETH"] 
datasets = [BTC,RIP,ETH]
for i in range(len(currencies)):
    currency=currencies[i]
    df=datasets[i]
    df.rename(columns={"Close": f"{currency}_Close", "Volume": f"{currency}_Volume"}, inplace=True)
    df.set_index("Open time", inplace=True)
    df = df[[f"{currency}_Close", f"{currency}_Volume"]]
    if len(combined_df)==0:
        combined_df=df
    else:  # otherwise, join this data to the main one
        combined_df=combined_df.join(df)
combined_df.fillna(method="ffill", inplace=True) # missing values filled with the previously known values


# In[280]:


print("Combined_DF")
combined_df.head()


# In[281]:


future_timeline=1 # to what we want to predict short term or long term 
currency="BTC" # which cryptocurrency we are predicting
combined_df['Future_Value']=combined_df[f'{currency}_Close'].shift(-future_timeline)


# standaridzation and normalization

# In[195]:


def preprocess(df):

    for col in df.columns:  # go through all of the columns
        if col != "Future_Value":  # normalize all ... except for the target itself!
            df[col] = df[col].pct_change()  # pct change "normalizes" the different currencies (each crypto coin has vastly diff values, we're really more interested in the other coin's movements)
            df = df.replace([np.inf, -np.inf], np.nan)
            df.dropna(inplace=True,axis=0)  # remove the nas created by pct_change
            df[col] = preprocessing.scale(df[col].values)  

    df.dropna(inplace=True)  # cleanup again... jic.
    return df

combined_df=preprocess(combined_df)


# In[196]:


def test_stationarity(x):
    rolmean = x.rolling(window=22,center=False).mean()
    rolstd = x.rolling(window=12,center=False).std()
    
    #Plot rolling statistics:
    orig = plt.plot(x, color='blue',label='Original')
    mean = plt.plot(rolmean, color='red', label='Rolling Mean')
    std = plt.plot(rolstd, color='black', label = 'Rolling Std')
    plt.legend(loc='best')
    plt.title('Rolling Mean & Standard Deviation')
    plt.show(block=False)
    
    #Perform Dickey Fuller test    
    result=adfuller(x)
    print('ADF Stastistic: %f'%result[0])
    print('p-value: %f'%result[1])
    pvalue=result[1]
    for key,value in result[4].items():
         if result[0]>value:
            print("The graph is non stationery")
            break
         else:
            print("The graph is stationery")
            break;
    print('Critical values:')
    for key,value in result[4].items():
        print('\t%s: %.3f ' % (key, value))
        
ts = combined_df['BTC_Close']      
test_stationarity(ts)


# spliting into train and validation

# In[197]:


times=sorted(combined_df.index.values)
last_5pct=sorted(combined_df.index.values)[-int(0.05*len(times))]
validation_df = combined_df[(combined_df.index >= last_5pct)]  # make the validation data where the index is in the last 5%
train_df = combined_df[(combined_df.index < last_5pct)]  


# In[198]:


print("Length validation dataset:",len(validation_df))
print("Length train dataset:",len(train_df))


# Getting features for predcitions

# In[201]:


feature_length=60  # next 1 min predcition for based on last 1 hour
future_timeline=1 


# In[202]:


def features(df):
    sequential_data=[]
    index=[]
    count=0
    prev_days = deque(maxlen=feature_length)
    for i in df.values:
        prev_days.append([n for n in i[:-1]])
        if len(prev_days)==feature_length:
            sequential_data.append([np.array(prev_days), i[-1]]) 
            index.append(df.index.values[count])
        count=count+1
            

    random.shuffle(sequential_data)
    X = []
    y = []
    #print(sequential_data)
    for seq, target in sequential_data:
        X.append(seq)
        y.append(target)
    return np.array(X), y,index

train_x, train_y,index_train=features(train_df) 
validation_x, validation_y,index_validation=features(validation_df)


# In[203]:


print((validation_x.shape))


# In[204]:


train_x_NN=train_x
validation_x_NN=validation_x
train_y_NN= np.array(train_y) 
validation_y_NN= np.array(validation_y) 


# In[205]:


train_x=train_x.reshape(len(train_x),360)
validation_x=validation_x.reshape(len(validation_x),360)


# Model

# In[206]:


#RBF +Constant kernel
np.random.seed(1)
kernel = C(1.0, (1e-3, 1e3)) * RBF(1, (1e-2, 1e2)) 
gp = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=9)
gp.fit(train_x, train_y)
print("GPML kernel: %s" % gp.kernel_)
print("Log-marginal-likelihood: %.3f"
      % gp.log_marginal_likelihood(gp.kernel_.theta))
y_pred, sigma = gp.predict(validation_x, return_std=True)
print("Value at Test points",y_pred)
print("Original Value at Test points:",validation_y)
print("Confidenne at Test point predictions ",1.9600 * sigma)
rms = sqrt(mean_squared_error(validation_y, y_pred))
print("RMSE is:",rms)


# In[208]:


#Matern+Constant kernel
from sklearn.gaussian_process.kernels import Matern
np.random.seed(1)
kernel = C(1.0, (1e-3, 1e3)) * Matern(length_scale=1.0, nu=1.5) 
gp = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=9)
gp.fit(train_x, train_y)
print("GPML kernel: %s" % gp.kernel_)
print("Log-marginal-likelihood: %.3f"
      % gp.log_marginal_likelihood(gp.kernel_.theta))
y_pred, sigma = gp.predict(validation_x, return_std=True)
print("Value at Test points",y_pred)
print("Original Value at Test points:",validation_y)
print("Confidenne at Test point predictions ",1.9600 * sigma)
rms = sqrt(mean_squared_error(validation_y, y_pred))
print("RMSE is:",rms)


# In[214]:


#DOT Product+Mattern Kernel
from sklearn.gaussian_process.kernels import DotProduct
np.random.seed(1)
kernel = C(1.0, (1e-3, 1e3)) * DotProduct() 
gp = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=9)
gp.fit(train_x, train_y)
print("GPML kernel: %s" % gp.kernel_)
print("Log-marginal-likelihood: %.3f"
      % gp.log_marginal_likelihood(gp.kernel_.theta))
y_pred, sigma = gp.predict(validation_x, return_std=True)
print("Value at Test points",y_pred)
print("Original Value at Test points:",validation_y)
print("Confidenne at Test point predictions ",1.9600 * sigma)
rms = sqrt(mean_squared_error(validation_y, y_pred))
print("RMSE is:",rms)


# In[236]:


#Constant+Rational Quadratic Kernels
from sklearn.gaussian_process.kernels import Matern,RationalQuadratic
np.random.seed(1)
kernel = C(1.0, (1e-3, 1e3)) * RationalQuadratic(length_scale=1.0, alpha=1.5)
gp = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=9)
gp.fit(train_x, train_y)
print("GPML kernel: %s" % gp.kernel_)
print("Log-marginal-likelihood: %.3f"
      % gp.log_marginal_likelihood(gp.kernel_.theta))
y_pred, sigma = gp.predict(validation_x, return_std=True)
print("Value at Test points",y_pred)
print("Original Value at Test points:",validation_y)
print("Confidenne at Test point predictions ",1.9600 * sigma)
rms = sqrt(mean_squared_error(validation_y, y_pred))
print("RMSE is:",rms)


# In[237]:


def plot(X,plot1,plot2):#the plotting fucntion in general
    Xi = list(range(len(X)))
    plt.xticks(Xi, X)
    plt.plot(Xi,plot1,marker='o',markersize=5,label = "Actual") 
    plt.plot(Xi,plot2,marker='o',markersize=5,label = "Predicted") 
    plt.xlabel('Time')
    plt.ylabel('Close Price')
    plt.title("Time vs Close price") 
    plt.legend()
    plt.show()


# In[238]:


predicted_df=pd.DataFrame(index=index_validation)
predicted_df['Predicted_Future_Value']=y_pred
actual_df=pd.DataFrame(index=index_validation)
actual_df['Future_Value']=validation_y
plot(predicted_df.index.values,actual_df['Future_Value'],predicted_df['Predicted_Future_Value'])


# In[217]:


def lighten_color(color, amount=0.5):
    import matplotlib.colors as mc
    import colorsys
    try:
        c = mc.cnames[color]
    except:
        c = color
    c = colorsys.rgb_to_hls(*mc.to_rgb(c))
    return colorsys.hls_to_rgb(c[0], 1 - amount * (1 - c[1]), c[2])


# In[221]:


plt.figure(figsize=(20,10))
plt.plot(index_train,train_y,"g.", label='Observations')
plt.plot(index_validation, validation_y, 'r.', label='Prediction')
plt.plot(index_validation, y_pred, 'b.', label='Prediction')
plt.fill(np.concatenate([index_validation, index_validation[::-1]]),
         np.concatenate([y_pred - 1.9600 * sigma,
                        (y_pred + 1.9600 * sigma)[::-1]]),
         alpha=.5, fc='b', ec='None', label='95% confidence interval')

plt.xlabel('$x$')
plt.ylabel('$f(x)$')
#plt.ylim(-10, 20)
#plt.legend(loc='upper left')


# Other Models

# In[248]:


#LINEAR + RIDGE
from sklearn.linear_model import Ridge
from sklearn.linear_model import Lasso

lr = LinearRegression()
lr.fit(train_x, train_y)

rr = Ridge(alpha=0.01) 
rr.fit(train_x, train_y)
rr100 = Ridge(alpha=100) #  comparison with alpha value
rr100.fit(train_x, train_y)

ll = Lasso(alpha=0.01) 
ll.fit(train_x, train_y)
ll100 = Lasso(alpha=100) #  comparison with alpha value
ll100.fit(train_x, train_y)


test_score_pred=lr.predict(validation_x)
test_score=np.sqrt(mean_squared_error(validation_y, test_score_pred))
Ridge_test_score_pred=rr.predict(validation_x)
Ridge_test_score=np.sqrt(mean_squared_error(validation_y, Ridge_test_score_pred))
Ridge_test_score100_pred=rr100.predict(validation_x)
Ridge_test_score100=np.sqrt(mean_squared_error(validation_y, Ridge_test_score100_pred))

Lasso_test_score_pred=ll.predict(validation_x)
Lasso_test_score=np.sqrt(mean_squared_error(validation_y, Lasso_test_score_pred))
Lasso_test_score100_pred=ll100.predict(validation_x)
Lasso_test_score100=np.sqrt(mean_squared_error(validation_y, Lasso_test_score100_pred))

print("linear regression test score:", test_score)
print("Ridge regression test score low alpha:", Ridge_test_score)
print("Ridge regression test score high alpha:", Ridge_test_score100)
print("Lasso regression test score low alpha:", Lasso_test_score)
print("Lasso regression test score high alpha:", Lasso_test_score100)


# In[250]:


#RNN


# In[252]:


import tensorflow as tf
from keras.models import Sequential
from keras.layers import Dense, SimpleRNN, Dropout,Flatten

regressor=Sequential()
#first RNN layer
regressor.add(SimpleRNN(512,activation="relu",return_sequences=True,input_shape=(train_x_NN.shape[1:])))
regressor.add(Dropout(0.25))
#second RNN layer
regressor.add(SimpleRNN(256,activation="relu",return_sequences=True))
regressor.add(Dropout(0.25))
regressor.add(SimpleRNN(512,activation="relu",return_sequences=True))
regressor.add(Dropout(0.35))
#fourth RNN layer
regressor.add(SimpleRNN(256,activation="relu",return_sequences=True))
regressor.add(Dropout(0.25))
#fifth RNN layer
regressor.add(SimpleRNN(128,activation="relu",return_sequences=True))
regressor.add(Dropout(0.25))
#convert the matrix to 1-line
regressor.add(Flatten())
#output layer
regressor.add(Dense(1))

regressor.compile(optimizer="adam",loss="mean_squared_error")
regressor.fit(train_x_NN,train_y_NN,epochs=10,batch_size=64)

predicted_data=regressor.predict(validation_x_NN)
rms=np.sqrt(mean_squared_error(validation_y_NN, predicted_data))
print("RMSE with RNN: ",rms)

